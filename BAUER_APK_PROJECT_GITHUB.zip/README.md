# BAUER – Simulador de Cuotas Android

Proyecto listo para generar un APK mediante GitHub Actions.

## Opción recomendada: GitHub

1. Crear un repositorio nuevo en GitHub.
2. Subir todos los archivos de esta carpeta.
3. Ir a **Actions**.
4. Ejecutar **Build Android APK**.
5. Cuando termine, abrir el workflow y descargar el artefacto **bauer-apk**.
6. Dentro del ZIP estará `app-debug.apk`, listo para instalar en Android.

El proyecto usa Capacitor y genera el proyecto Android durante el workflow, por lo que no es necesario subir la carpeta `android/`.

## Funciones
- Diseño premium para celular.
- Fondo visual con celulares.
- Guaraní paraguayo con puntos: `Gs. 1.000.000`.
- Columna **EL FRANQUICIADO RECIBE**.
- Tasa de porcentaje oculta.
- Cálculo automático.
- 6, 12, 15, 18 y 24 meses.
